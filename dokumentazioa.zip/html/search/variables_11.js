var searchData=
[
  ['value',['value',['../classapplication_1_1_power_command.html#ae58316f8383e4c6e99dc3ade99315288',1,'application::PowerCommand']]]
];
