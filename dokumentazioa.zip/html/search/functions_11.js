var searchData=
[
  ['updatenewdata',['updateNewData',['../classapplication_1_1_d_b_conection.html#a4e8bbf785d6894a080cd12a437060d36',1,'application::DBConection']]],
  ['uploadnewdata',['uploadNewData',['../classapplication_1_1_command.html#ae2874fd25885ea45bc07d8806cee1f24',1,'application.Command.uploadNewData()'],['../classapplication_1_1_d_b_conection.html#a6404f06dcb11a6c6788305add546da90',1,'application.DBConection.uploadNewData()'],['../classapplication_1_1_power_command.html#a9d6c8b556796416edde2c244f45cb93d',1,'application.PowerCommand.uploadNewData()'],['../classapplication_1_1_test.html#afdf6d4bbd8d5c8b019295ee62e5cc85d',1,'application.Test.uploadNewData()'],['../classapplication_1_1_test_data.html#a488b131821882ca3eae8a67bcf7ee2fa',1,'application.TestData.uploadNewData()']]]
];
