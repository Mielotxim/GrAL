var searchData=
[
  ['name',['name',['../classapplication_1_1_power_command.html#a4a702fa9dfbbe08300041a9e1fcd8b91',1,'application.PowerCommand.name()'],['../classapplication_1_1_sub_process.html#a3ee39e6ece48d259ed882d973412d626',1,'application.SubProcess.name()']]],
  ['newfaseinstalling',['newFaseInstalling',['../classview_1_1_work_zone_controller.html#a06e597baacda8c15907874ddc565e27e',1,'view::WorkZoneController']]],
  ['newfasetesting',['newFaseTesting',['../classview_1_1_work_zone_controller.html#aa2c775b9ed8d6e4bab6d474b6eec1beb',1,'view::WorkZoneController']]],
  ['newinstbarcode',['newInstBarcode',['../classview_1_1_work_zone_controller.html#af757999b8fdc956f962a289a66d82e6a',1,'view::WorkZoneController']]],
  ['newtestbarcode',['newTestBarcode',['../classview_1_1_work_zone_controller.html#a280a9bd89146bbe4a9b9af03121ac2fc',1,'view::WorkZoneController']]],
  ['newuser',['newUser',['../classview_1_1_configuration_controller.html#a9595b62dab7a85bdf36573b77bc63e97',1,'view.ConfigurationController.newUser()'],['../classapplication_1_1_d_b_conection.html#a546e0e9cbb7491041d941110d1493dd2',1,'application.DBConection.newUser()']]],
  ['numberofconnections',['numberOfConnections',['../classapplication_1_1_socket_list.html#a5fd3eda09b30e8ee6acf1068815badd1',1,'application.SocketList.numberOfConnections()'],['../classapplication_1_1_sub_process.html#a875d09088ee09464f0e0f0100b5ba285',1,'application.SubProcess.numberOfConnections()']]]
];
