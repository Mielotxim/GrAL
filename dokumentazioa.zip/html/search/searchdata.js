var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwx",
  1: "cdghmpstwx",
  2: "av",
  3: "cdghmpstwx",
  4: "abcdefghilmnoprstuwx",
  5: "abcdfghilmnoprstuvwx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones",
  5: "Variables"
};

