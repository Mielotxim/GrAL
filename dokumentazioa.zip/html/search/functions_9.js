var searchData=
[
  ['login',['login',['../classview_1_1_g_u_i_controller.html#a8b23abbb764e41c9fb714da0f119db16',1,'view::GUIController']]]
];
