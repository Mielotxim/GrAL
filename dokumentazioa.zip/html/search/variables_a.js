var searchData=
[
  ['name',['name',['../classapplication_1_1_power_command.html#a4a702fa9dfbbe08300041a9e1fcd8b91',1,'application.PowerCommand.name()'],['../classapplication_1_1_sub_process.html#a3ee39e6ece48d259ed882d973412d626',1,'application.SubProcess.name()']]],
  ['newfaseinstalling',['newFaseInstalling',['../classview_1_1_work_zone_controller.html#a06e597baacda8c15907874ddc565e27e',1,'view::WorkZoneController']]],
  ['newfasetesting',['newFaseTesting',['../classview_1_1_work_zone_controller.html#aa2c775b9ed8d6e4bab6d474b6eec1beb',1,'view::WorkZoneController']]],
  ['numberofconnections',['numberOfConnections',['../classapplication_1_1_socket_list.html#a5fd3eda09b30e8ee6acf1068815badd1',1,'application.SocketList.numberOfConnections()'],['../classapplication_1_1_sub_process.html#a875d09088ee09464f0e0f0100b5ba285',1,'application.SubProcess.numberOfConnections()']]]
];
