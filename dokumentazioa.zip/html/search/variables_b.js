var searchData=
[
  ['operatorid',['operatorID',['../classapplication_1_1_master_config.html#ad2d0b0a86ca8d11546f2bebd54c8aad7',1,'application.MasterConfig.operatorID()'],['../classapplication_1_1_test_data.html#a419c4bdec348e6ebc3c3a79966fe3f83',1,'application.TestData.operatorID()']]]
];
