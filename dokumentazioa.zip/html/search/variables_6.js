var searchData=
[
  ['hasbeeninitialiced',['hasBeenInitialiced',['../classview_1_1_configuration_controller.html#a0982aac6288f1eef75f4c714dd2c0eb1',1,'view::ConfigurationController']]],
  ['host',['host',['../classapplication_1_1_d_b_conection.html#af6470cfdf1d1222b62e53e5452e91cfc',1,'application::DBConection']]]
];
