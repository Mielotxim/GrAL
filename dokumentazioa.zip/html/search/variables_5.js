var searchData=
[
  ['guardar',['guardar',['../classview_1_1_configuration_controller.html#ab72e804fbc0fd5334305f424f23c08ba',1,'view::ConfigurationController']]],
  ['guic',['guic',['../classview_1_1_main.html#a91710c52d452e826a80f401fa15e67c0',1,'view::Main']]]
];
