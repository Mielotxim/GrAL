var searchData=
[
  ['response',['response',['../classapplication_1_1_power_command.html#a7e284cfdb2e0dbe7a9e329fcdecdc47e',1,'application::PowerCommand']]],
  ['result',['result',['../classapplication_1_1_power_command.html#aa302df4da648c080238b65b38ec4f953',1,'application::PowerCommand']]]
];
