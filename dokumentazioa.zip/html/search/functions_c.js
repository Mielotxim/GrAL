var searchData=
[
  ['operatorsystem',['operatorSystem',['../classapplication_1_1_master.html#a7cce3ef636d2eef9818e8c50214bfd8a',1,'application::Master']]]
];
